const Sequelize = require('sequelize');
const sequelize = new Sequelize('inpg', 'root', 'tropical', {
        host:'localhost',
        dialect: "mysql"

} )

module.exports = {
    Sequelize:Sequelize,
    sequelize:sequelize
}