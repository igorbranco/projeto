var bd = require('./bd')

const Postagem = bd.sequelize.define('postagens', {

    titulo:{
        type:bd.Sequelize.STRING
    },
    conteudo:{
        type:bd.Sequelize.TEXT

    }

} )

module.exports = Postagem